import './App.css';
import AppRouter from './Routes/Router';

function App() {
    return (
        <div className="App">
            <AppRouter />
        </div>
    );
}

export default App;